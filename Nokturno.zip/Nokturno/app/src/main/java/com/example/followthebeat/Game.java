package com.example.followthebeat;

import android.app.Dialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.util.Random;

public class Game extends AppCompatActivity {
    Handler mHandler = new Handler();   // Handler methods para ma implement yung mga delays bago mag execute (Parang wait muna ng 1 second bago mag execute yung code)
    MediaPlayer player;                 // MediaPlayer para mag play ng music files
    Random random = new Random();       // Para magkaroon ng randomizer
    CountDownTimer countDownTimer;      // Para magamit yung countdown timer function

    ImageButton medallionButton, swordButton, skullButton, hornButton; // Variable button para ma access natin yung mga buttons sa xml and ma access ng mga class dito.
    ConstraintLayout overlay;
    TextView livesText;
    TextView timerText;

    // Other variables na need sa mga ibang classes.
    String sequence = "";
    String userInput;
    int currentSequence, i;

    // Game Settings. Pwede i change here.
    int maxSequence = 6;    // Kung ilang stage need i complete
    int gameSpeed = 1000;   // 1000 = 1 second. Ginagamit sa mga delays like hintay muna ng 1 second bago i run yung method.
    int playerLives = 3;
    long timer = 60000;
    long currentTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        // Para maging immersive view lang yung UI
        overlay = findViewById(R.id.gamelayout);
        overlay.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);

        // Kunin yung id ng buttons sa xml para pwede natin i-modify dito
        medallionButton = findViewById(R.id.button_medallion);
        swordButton = findViewById(R.id.button_sword);
        skullButton = findViewById(R.id.button_skull);
        hornButton = findViewById(R.id.button_horn);

        // Kunin yung id ng textView sa xml para pwede natin i-modify dito
        livesText = findViewById(R.id.livesText);
        // Initialize the timer TextView
        timerText = findViewById(R.id.TimerText);


        toggleButtons(false);   // Method para di muna magalaw ng players yung buttons. Maiwasan bugs.

        showTutorial();     // Method para ma show muna yung tutorial sa players pag ka start ng class na ito.
    }

// Show ng tutorial
    private void showTutorial() {

        final Dialog dialog = new Dialog(Game.this);

        dialog.setContentView(R.layout.dialog_tutorial);
        dialog.show();

        addSequence();      // Method para mag add na ng sequence na need sundan ng players. Start na agad para may magayahan na yung players on the start
        livesText.setText("Lives: " + playerLives);     // Set na yung text sa player lives kung ilan yung buhay nila (playerLives)
        // Pag na dismiss na ng user yung tutorial dialog. I run na yung handler method 'startSequence' na may delay naka depende sa 'gameSpeed'.

        dialog.setOnDismissListener(dialogInterface -> {
            mHandler.postDelayed(() -> {
                startSequence.run(); // Mag Start na yung sequence
            }, gameSpeed); // Mag Start na yung timer after the gameSpeed delay
        });
    }
    // Method ng start timer
    private void startTimer() {
        countDownTimer = new CountDownTimer(timer, 1000) { // 60 seconds yung set ng timer and yung countdown niya is 1 sec
            public void onTick(long millisUntilFinished) {

                timerText.setText("Timer: " + millisUntilFinished / 1000);
                currentTimer = millisUntilFinished;

            }
            // Pag nag naubos yung timer lalabas yung dead dialog
            public void onFinish() {
                // Lalabas yung death dialog
                final Dialog dialog = new Dialog(Game.this);
                dialog.setContentView(R.layout.dialog_death);
                dialog.show();

                // babalik sa startmenu
                mHandler.postDelayed(() -> {
                    dialog.dismiss(); // Dismiss the dialog
                    Intent intent = new Intent(Game.this, StartMenu.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK); // Clear back stack
                    startActivity(intent);
                    finish();
                }, 1000); // 1 seconds delay bago bumalik sa startmenu or in short authomatical deds pag naubos yung timer
            }
        }.start(); // Start ng countdown timer
    }

//  method ng pag Pause ng timer
    @Override
    protected void onPause() {
        super.onPause();
        if (countDownTimer != null) {
            timer = currentTimer;
            countDownTimer.cancel();
        }
    }

// method na nag expand ng button and reset or animation
    private void expandButtonAndReset(ImageButton button) {
        ScaleAnimation anim = new ScaleAnimation(
                1f, 1.2f,
                1f, 1.2f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
        );
        anim.setDuration(200); // Duration ng animation
        anim.setFillAfter(true);

        // Animation listener para mareset yung expansion or paglaki ng imagebutton
        anim.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                // Start ng Animation
            }
            // ended ng animation
            @Override
            public void onAnimationEnd(Animation animation) {
                // ended ng Animation , para ma-revert yung button size
                ScaleAnimation revertAnim = new ScaleAnimation(
                        1.2f, 1f,
                        1.2f, 1f,
                        Animation.RELATIVE_TO_SELF, 0.5f,
                        Animation.RELATIVE_TO_SELF, 0.5f
                );
                revertAnim.setDuration(200); // Duration ng animation
                revertAnim.setFillAfter(true);
                button.startAnimation(revertAnim);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
                // Pag ulit lang ng Animation
            }
        });

        button.startAnimation(anim);
    }

// Method para sa pag start ng sequence. Dito yung pinapakita sa player yung need sundan.
    private final Runnable startSequence = new Runnable() {

        @Override
        public void run() {

            // If loop para ma iterate bawat sequence.
            if (i < sequence.length()) {
                // Iterate bawat values ng sequence like kada item sa sequence kinukuha natin para mapakita sa players.
                char c = sequence.charAt(i);

                // Method na pwede mag set ng color overlay sa lahat ng buttons. "Default" para matanggal yung color overlay. Para lang ito sa mga previous change colors.
                changeButtonOverlayColor("default");

                // '0' = Medallion Button, '1' = Sword Button, '2' = Skull Button, '3' = Horn Button.
                if (c == '0') {
                    playSound("Medallion");   // Method para mag play ng sound depende kung anong button ang nakuha sa sequence.
                    expandButtonAndReset(medallionButton);
                } else if (c == '1') {
                    playSound("Sword");
                    expandButtonAndReset(swordButton);
                } else if (c == '2') {
                    playSound("Skull");
                    expandButtonAndReset(skullButton);
                } else if (c == '3') {
                    playSound("Horn");
                    expandButtonAndReset(hornButton);
                }
                i++; // Add yung variable 'i' para ma determine sa if else mamaya kung mag loop pa or hinde.
                mHandler.postDelayed(this, gameSpeed);  // Tawagin ulit itong method pero may delay. Basically ito yung nagpapaloop dito.

                // Kung na iterate na natin lahat ng sequence, stop na yung loop
            } else {
                playSound("Turn");
                changeButtonOverlayColor("#B2808080");
                // Kinalahati yung delay ng half para mas mabilis ng onti mag run yung method para mag start na mapindot ng players yung buttons pagkatapos ipakita yung sequence
                mHandler.postDelayed(startUserInput, (long) (0.5 * gameSpeed));
            }
        }
    };
    // Method para mag start na magpindot ng buttons yung players.
    private final Runnable startUserInput = new Runnable() {
        public void run() {
            startTimer();
            userInput = "";         // reset lang yung userinput na player. Para sa previous input lang ito
            currentSequence = 0;    // Reset din yung currentSequence. Sa previous lang din ito.
            changeButtonOverlayColor("default");
            toggleButtons(true);
        }
    };

    // Listener sa pagka click ng medallion button
    public void onClickRed(View view) {
        playSound("Medallion");
        checkSequence('0');
        expandButtonAndReset(medallionButton);
    }

    // Listener sa pagka click ng sword button
    public void onClickBlue(View view) {
        playSound("Sword");
        checkSequence('1');
        expandButtonAndReset(swordButton);
    }

    // Listener sa pagka click ng skull button
    public void onClickYellow(View view) {
        playSound("Skull");
        checkSequence('2');
        expandButtonAndReset(skullButton);
    }

    // Listener sa pagka click ng horn button
    public void onClickGreen(View view) {
        playSound("Horn");
        checkSequence('3');
        expandButtonAndReset(hornButton);
    }

    // Method para ma check yung bawat input ng user kung tama ba sa sequence.
    private void checkSequence(char x) {
        userInput += x;     // Add dito lahat ng mga pinindot ng user para ma check.

        // Kung pareho ng length ng input ng user yung length ng sequence at kung pareho yung sequence at input.
        if (userInput.length() == sequence.length() && userInput.equals(sequence)) {
            toggleButtons(false);
            if (sequence.length() == maxSequence) mHandler.postDelayed(playerComplete, (long) (gameSpeed*0.7));     // Kung itong stage ba ay last na then run na yung playerComplete method
            else mHandler.postDelayed(playerCorrect, (long) (gameSpeed*0.7));                                       // Kung di pa last stage then run na yung playerCorrect method para mag next sequence na.

            // Kung tama yung input ng user bawat sequence.
        } else if (x == sequence.charAt(currentSequence)) {
            currentSequence++;  // Add yung currentSequence para lang ma iterate next yung bawat sequence

            // Hindi tugma yung ininput ng user sa current sequence.
        } else {
            toggleButtons(false);
            playerLives -= 1;                   // Bawas lives
            livesText.setText("Lives: " + playerLives); // Update lang yung text sa player lives
            playSound("Wrong");
            changeButtonOverlayColor("#B2ED514E");   // Flash lang ng color red sa lahat ng buttons.

            // Kung wala ng lives yung player, run na yung playerDeath method.
            if (playerLives == 0)  playerDeath();
                // Kung meron pa, then run lang yung playerWrong method.
            else mHandler.postDelayed(playerWrong, (long) (gameSpeed * 0.5));

        }
    }

    // Method para mag add ng panibagong sequence na need gayahin ng players. Kada stage, padagdag ng padagdag yung sequence.
    private void addSequence() {
        sequence += random.nextInt(4);  // Pick random number 0-3
        i = 0;  // Reset lang yung variable para ma iterate lahat ng sequence.
    }

    // Method kung nagkamali yung player. Reset lang yung value ng userInput at CurrentSequence para ma restart lang yung pag check ng bawat values na ininput ng user.
    private final Runnable playerWrong = new Runnable() {
        @Override
        public void run() {
            userInput = "";
            currentSequence = 0;
            changeButtonOverlayColor("default");
            toggleButtons(true);
        }
    };


    // Method para mag add ng color overlay sa button lahat. Ginagamit lang ito sa mga correct, turn, and wrong warning sa users.
    private void changeButtonOverlayColor(String color) {
        if (color.equals("default")) {
            medallionButton.setImageTintList(ColorStateList.valueOf(Color.parseColor("#00FFFFFF")));
            swordButton.setImageTintList(ColorStateList.valueOf(Color.parseColor("#00FFFFFF")));
            skullButton.setImageTintList(ColorStateList.valueOf(Color.parseColor("#00FFFFFF")));
            hornButton.setImageTintList(ColorStateList.valueOf(Color.parseColor("#00FFFFFF")));
        } else {
            medallionButton.setImageTintList(ColorStateList.valueOf(Color.parseColor(color)));
            swordButton.setImageTintList(ColorStateList.valueOf(Color.parseColor(color)));
            skullButton.setImageTintList(ColorStateList.valueOf(Color.parseColor(color)));
            hornButton.setImageTintList(ColorStateList.valueOf(Color.parseColor(color)));
        }
    }

    // Method kung tama yung player.
    private final Runnable playerCorrect = new Runnable() {
        @Override
        public void run() {
            playSound("Correct");
            onPause();
            changeButtonOverlayColor("#B200E676");
            addSequence();
            mHandler.postDelayed(startSequence, gameSpeed);
        }
    };

    // Method kung na complete na ng player yung maximum stage ng sequence
    private final Runnable playerComplete = new Runnable() {
        @Override
        public void run() {
            final Dialog dialog = new Dialog(Game.this);
            dialog.setContentView(R.layout.dialog_tutorial_vault);
            dialog.show();
            // Automatically reset yung game after a delay
            mHandler.postDelayed(() -> {
                dialog.dismiss(); // Dismiss ng dialog
                Intent intent = new Intent(Game.this, clue1.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK); // Clear back stack
                startActivity(intent);
                finish();
            }, 5000); //  delay seconds

        }
    };

    // Method kung wala ng lives yung player. Magpapakita lang ng dialog.
    private void playerDeath() {
        final Dialog dialog = new Dialog(Game.this);
        dialog.setContentView(R.layout.dialog_death);
        dialog.show();

        // Automatically reset yung game after a delay
        mHandler.postDelayed(() -> {
            dialog.dismiss(); // Dismiss ng dialog
            Intent intent = new Intent(Game.this, StartMenu.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK); // Clear back stack
            startActivity(intent);
            finish();
        }, 3000); //  delay seconds

    }

    // Method para sa pag toggle off/on ng buttons.
    public void toggleButtons(boolean x) {
        medallionButton.setEnabled(x);
        swordButton.setEnabled(x);
        skullButton.setEnabled(x);
        hornButton.setEnabled(x);
    }

    // Method para mag play ng sound.
    private void playSound(String sound) {
        int soundResource;

        // If else depende sa attributes ng pag tawag ng method na toh [ex. playSound("Sword")]. soundResource para makuha lang yung mp3 file sa folder.
        if (sound.equals("Medallion")) soundResource = R.raw.medallionsound;
        else if (sound.equals("Sword")) soundResource = R.raw.swordsound;
        else if (sound.equals("Skull")) soundResource = R.raw.skullsound;
        else if (sound.equals("Horn")) soundResource = R.raw.hornsound;
        else if (sound.equals("Wrong")) soundResource = R.raw.wrongsound;
        else if (sound.equals("Turn")) soundResource = R.raw.playerturn;
        else if (sound.equals("Correct")) soundResource = R.raw.playercorrect;
        else soundResource = R.raw.playercorrect;

        // Kung wala pang sound nag play, then gumawa na ng bagong player para mag play.
        if (player == null) {
            player = MediaPlayer.create(Game.this, soundResource); // Set na natin yung gusto natin i play na sound para i-play mamaya

            // Kung tapos na mag play yung sound file
            player.setOnCompletionListener(mp -> {
                mp.release();   // Release na natin yung media player para di maaksaya sa resource (baka mag lag)
                player = null;  // Set na natin yung player sa wala para sa susunod na iplaplay.
            });

            // Kung may nag play pa na sound, then exit agad natin iyun and play na natin yung bagong sound na pinili ng user.
        } else {
            player.release();
            player = MediaPlayer.create(Game.this, soundResource);
            player.setOnCompletionListener(mp -> {
                mp.release();
                player = null;
            });
        }
        player.start(); // Start na i play yung sound.
    }

}