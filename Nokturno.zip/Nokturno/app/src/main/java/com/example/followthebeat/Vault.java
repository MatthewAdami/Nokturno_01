package com.example.followthebeat;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

public class Vault extends AppCompatActivity {
    ConstraintLayout overlay;// contraintlayout tinatawag niya sa xml which is yung id ng mismo xml
    private final String correctCombination = "1386"; // Combination ng vault
    private EditText Combination;
    private MediaPlayer player;

    // fullscreen ng ui
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vault);
        overlay = findViewById(R.id.valultlayout);
        overlay.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN);
        Combination = findViewById(R.id.Combination);

        // Nag add ako TextWatcher para basahin niya pagbabago sa edittext
        Combination.addTextChangedListener(new TextWatcher() {

            //this method ay tinatawag before the text change
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }
            // Eto naman is pag tinatawag niya yung text pag nag iiba
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            // method na nagchecheck ng combination if tama or mali
            @Override
            public void afterTextChanged(Editable s) {
                String input = s.toString();
                if (input.length() == correctCombination.length()) { // Checker ng  input length if matches siya sa combination
                    if (input.equals(correctCombination)) { // if yung input ay tama mag pupunta na siya sa complete
                        playSound("Correct");
                        startActivity(new Intent(Vault.this, Complete.class));
                        finish();
                    } else { // if mali yung input ng user mag shashake siya and mag kakaron ng toast na wrong and maclear yung input
                        playSound("Wrong");
                        Toast.makeText(Vault.this, "Wrong combination", Toast.LENGTH_SHORT).show();
                        shakeEditText(Combination);
                        Combination.setText("");
                    }
                }
            }
        });
    }
    //animation ng shakeEditText
    private void shakeEditText(EditText editText) {
        int delta = 30; // distance ng shake animation
        ObjectAnimator shakeAnimator = ObjectAnimator.ofFloat(editText, "translationX", 0, delta, -delta, delta, -delta, delta, 0);
        shakeAnimator.setDuration(500); // duration
        shakeAnimator.setRepeatCount(0); // numbers ng repeat ng shake
        shakeAnimator.start();
    }
    // sound player ng correct and wrong
    private void playSound(String sound) {
        int soundResource;

        if (sound.equals("Correct")) soundResource = R.raw.playercorrect;
        else soundResource = R.raw.wrongsound;

        if (player == null) {
            player = MediaPlayer.create(Vault.this, soundResource);
            player.setOnCompletionListener(mp -> {
                mp.release();
                player = null;
            });
        } else {
            player.release();
            player = MediaPlayer.create(Vault.this, soundResource);
            player.setOnCompletionListener(mp -> {
                mp.release();
                player = null;
            });
        }
        player.start();
    }
}
